# Dirty December Paystack API starter

## Included
- Menu order form and embedded poster.
- Server-side Paystack transaction initialization (GHS converted to pesewas).
- Server-side transaction verification on callback.
- Signed webhook endpoint starter.

## Run
1. Install Node.js 18 or newer.
2. Copy `.env.example` to `.env`.
3. Put your Paystack TEST secret key in `.env`.
4. Run `npm install`, then `npm start`.
5. Visit `http://localhost:3000`.

Keep the Paystack secret key on the server only. Never paste it into the HTML or share it in chat.
Set `SITE_URL` to your deployed HTTPS domain when hosting. Configure
`https://YOUR-DOMAIN/api/paystack-webhook` in your Paystack dashboard.

Before production, save orders in a database, process webhook events idempotently,
send customer confirmation, and test success/cancel/failure cases. This starter does
not yet store orders or send email/SMS. Use current Paystack documentation for account
and hosting-specific settings.
