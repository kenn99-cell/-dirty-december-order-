require('dotenv').config();
const express = require('express');
const crypto = require('crypto');
const path = require('path');
const app = express();
app.use(express.json({limit:'100kb'}));
app.use(express.static(path.join(__dirname,'public')));
const PORT = process.env.PORT || 3000;
const SECRET = process.env.PAYSTACK_SECRET_KEY;
const SITE_URL = process.env.SITE_URL || `http://localhost:${PORT}`;
const PACKAGES = {Prestige:3000, Elite:1000, Premium:750, Essential:450};

app.post('/api/initialize-payment', async (req,res) => {
  try {
    if (!SECRET) return res.status(500).json({error:'Payment API is not configured on the server.'});
    const {name,phone,email,package:pkg,notes=''} = req.body || {};
    if (!name || !phone || !email || !PACKAGES[pkg]) return res.status(400).json({error:'Enter your name, phone, valid email and package.'});
    const reference = `DD-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
    const payload = {
      email, amount: PACKAGES[pkg]*100, currency:'GHS', reference,
      callback_url:`${SITE_URL}/payment/callback`,
      metadata:{customer_name:String(name).slice(0,100),phone_number:String(phone).slice(0,40),package:pkg,special_requests:String(notes).slice(0,300)}
    };
    const r = await fetch('https://api.paystack.co/transaction/initialize',{
      method:'POST', headers:{Authorization:`Bearer ${SECRET}`,'Content-Type':'application/json'}, body:JSON.stringify(payload)
    });
    const data = await r.json();
    if (!r.ok || !data.status || !data.data?.authorization_url) {
      console.error('Paystack initialize error:',data);
      return res.status(502).json({error:'Paystack could not start payment. Please try again.'});
    }
    res.json({authorization_url:data.data.authorization_url,reference});
  } catch(e) { console.error(e); res.status(500).json({error:'Server error starting payment.'}); }
});

app.get('/payment/callback', async (req,res) => {
  const reference = req.query.reference;
  if (!reference) return res.status(400).send('Missing payment reference.');
  try {
    if (!SECRET) return res.status(500).send('Payment API is not configured.');
    const r = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,{
      headers:{Authorization:`Bearer ${SECRET}`}
    });
    const result = await r.json();
    if (!r.ok || !result.status || !result.data) return res.status(502).send('Could not verify payment. Contact the organizer.');
    const tx = result.data;
    const expectedPackage = tx.metadata?.package;
    const amount = PACKAGES[expectedPackage];
    if (tx.status !== 'success' || tx.currency !== 'GHS' || !amount || tx.amount !== amount*100)
      return res.status(400).send('Payment was not verified as successful. Contact the organizer.');
    // TODO: save the verified order in a database and trigger confirmation notification.
    res.send(`<main style="font-family:Arial;background:#100909;color:white;padding:35px;max-width:600px;margin:30px auto;border:2px solid #ffd629;border-radius:14px"><h1 style="color:#ffd629">Payment verified</h1><p>Paystack reports this payment as successful.</p><p>Reference: ${String(reference).replace(/[<>&"]/g,'')}</p><p>Reservations: 0598300381</p></main>`);
  } catch(e) { console.error(e); res.status(500).send('Error verifying payment.'); }
});

// Set this URL as the webhook URL in Paystack dashboard.
// For production, store orders and handle duplicate events idempotently.
app.post('/api/paystack-webhook', express.raw({type:'application/json'}), (req,res) => {
  if (!SECRET) return res.sendStatus(500);
  const signature = req.headers['x-paystack-signature'];
  const expected = crypto.createHmac('sha512',SECRET).update(req.body).digest('hex');
  if (!signature || signature !== expected) return res.sendStatus(401);
  let event; try { event=JSON.parse(req.body.toString('utf8')); } catch { return res.sendStatus(400); }
  if (event.event === 'charge.success') console.log('Successful charge event:',event.data?.reference);
  res.sendStatus(200);
});
app.listen(PORT,()=>console.log(`Dirty December server listening on ${SITE_URL}`));
